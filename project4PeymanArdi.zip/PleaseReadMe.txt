A note to marker: 

My GUI is designed that you have to pick one query up from selection 
and then you have to provide the nesseccary data in fields and press 
Send Query. Query result will be displaied below. 

Don't worry about filling all the fileds. ONLY fill the fileds that are relevant 
to the query you picked in step1. 

Steps: 
1. Pick up query from drop down. 
2. Fill up fields only relavant to that query. 
3. press Send Query. 
4. Query result and time get updated in related boxes. 

You cannot send multiple query from this GUI. 